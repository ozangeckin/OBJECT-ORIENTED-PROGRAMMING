#include"email.h"

 //default constructor
    Email::Email():Document()
    {
        sender="";
        recipient="";
        title="";
    }
    //parameterized constructor
    Email::Email(string text_,string sender_,string recipient_,string title_):Document(text_)
    {
        sender=sender_;
        recipient=recipient_;
        title=title_;
    }
    //setter for sender
    void Email::setSender(string sender_)
    {
        sender=sender_;
    }
    //setter for title
    void Email::setTitle(string title_)
    {
        title=title_;
    }
    //setter for receipient
    void Email::setRecipient(string recipient_)
    {
        recipient=recipient_;
    }
    //getter for title
    string Email::getTitle()const
    {
        return title;
    }
    //accessor for sender
    string Email::getSender()const
    {
        return sender;
    }
    //accessor for recipient
    string Email::getRecipient()const
    {
        return recipient;
    }
    //overloading of = operator
    Email& Email::operator=(const Email& otherEmail)
    {
        Document::setText(otherEmail.getText());
        sender=otherEmail.sender;
        recipient=otherEmail.recipient;
        title=otherEmail.title;

        return *this;
    }