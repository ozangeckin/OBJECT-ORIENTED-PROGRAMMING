#ifndef FILE_H
#define FILE_H
#include "document.h"
class File:public Document{
    public:
        File();
        File(string pathName_,string text_);
        string getPathName()const;
        void setPathName(string pathName_);
        File& operator=(const File& otherFile); 
    private:
        string pathName;
};

#endif