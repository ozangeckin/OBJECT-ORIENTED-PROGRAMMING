#include"file.h"

File::File():Document(){
    pathName="";
}
File::File(string pathName_,string text_):Document(text_){
    pathName=pathName_;
}

string File::getPathName()const{
    return pathName;
}
void File::setPathName(string pathName_){
    pathName=pathName_;
}
File& File::operator=(const File& otherFile){
    Document::setText(otherFile.getText());
    pathName=otherFile.pathName;
    return *this;
}