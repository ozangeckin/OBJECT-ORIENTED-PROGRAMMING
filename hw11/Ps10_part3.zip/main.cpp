#include"email.h"
#include"file.h"


bool ContainsKeyword(Document& docObject, string keyword)
   {
       if (docObject.getText().find(keyword) != string::npos)
       return true;
       return false;
   }

int main(){
    Email eObje1("What day is it today?","Will Smith","Johnny Deep","Best");
    Email eObje2("Shall we go to the cinema tomorrow?","Will Aniston","Jennefer Jonson","Meet");
    File f1("Math Notes","C:/Doc/Math"),f2("C Notes","C;/Doc/C");

    if(ContainsKeyword(eObje1,"today")){
        cout<<"Email contains 'today'"<<endl;
    }else{
        cout<<"Email not contains 'today'"<<endl;
    }
    if(ContainsKeyword(eObje2,"today")){
        cout<<"Email2 contains 'today'"<<endl;
    }else{
        cout<<"Email2 not contains 'today'"<<endl;
    }
    
     if(ContainsKeyword(f1,"Math")){
        cout<<"File contains 'today'"<<endl;
    }else{
        cout<<"File not contains 'today'"<<endl;
    }
      if(ContainsKeyword(f2,"Math")){
        cout<<"File contains 'Picture'"<<endl;
    }else{
        cout<<"File not contains 'Picture'"<<endl;
    }

}