#include "document.h"

Document::Document(){
    text="";
}
Document::Document(string text_){
    text=text_;
}
string Document::getText()const{
    return text;
}
void Document::setText(string text_){
    text=text_;
}
Document& Document::operator=(const Document& otherText){
    text=otherText.text;
    return *this;
}