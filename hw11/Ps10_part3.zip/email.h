#ifndef EMAIL_H
#define EMAIL_H
#include"document.h"

class Email:public Document{
    public:
        Email();
        Email(string text_,string sender_,string recipient_,string title_);
        void setSender(string sender_);
        void setTitle(string title_);
        void setRecipient(string recipient_);
        string getSender()const;
        string getRecipient()const;
        string getTitle()const;
        Email& operator=(const Email& otherEmail);
    private:
        string sender;
        string recipient;
        string title;
};
#endif