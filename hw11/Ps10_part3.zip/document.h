#ifndef DOCUMENT_H
#define DOCUMENT_H
#include<iostream>
#include<string>
using namespace std;
class Document{

    public:
        Document();
        Document(string text_);
        string getText()const;
        void setText(string text_);
        Document& operator=(const Document& otherText);
    private:
        string text;
};
#endif