#include "creditcardpayment.h"

CreditCardPayment::CreditCardPayment() : Payment(), nameOnCard(""), expirationDate(""), cardNumber("")
{

}

CreditCardPayment::CreditCardPayment(float creditOfPayment,string nameOnCard_, string expirationDate_, string cardNumber_):Payment(creditOfPayment){
    nameOnCard=nameOnCard_;
    expirationDate=expirationDate_;
    cardNumber=cardNumber_;
}

void CreditCardPayment::paymentDetails()
{
	cout << "Amount of credit card payment: $" << getAmountOfPayment() << endl;
	cout << "Name on the credit card: " << nameOnCard << endl;
	cout << "Expiration date: " << expirationDate << endl;
	cout << "Credit card number: " << cardNumber << endl;	
}