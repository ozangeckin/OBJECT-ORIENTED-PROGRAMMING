#include "payment.h"
#include<iostream>

using namespace std;

Payment::Payment(){
    amountOfPayment=0;
}
Payment::Payment(float amountOfPayment_){
    amountOfPayment=amountOfPayment_;
}
float Payment::getAmountOfPayment(){
    return amountOfPayment;
}
void Payment::setAmountOfPayment(float amountOfPayment_){
    amountOfPayment=amountOfPayment_;
}
void Payment::paymentDetails(){
    cout<<"Amoun of the payment : "<<amountOfPayment<<" $"<<endl;
}