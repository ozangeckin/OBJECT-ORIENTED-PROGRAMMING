#ifndef CREDITCARDPAYMENT_H
#define CREDITCARDPAYMENT_H
#include "payment.h"

class CreditCardPayment : public Payment
{
    public:
	    CreditCardPayment();
	    CreditCardPayment(float creditOfPayment, string nameOnCard_, string expirationDate_, string cardNumber_);
	    void paymentDetails();
    private:
	    string nameOnCard;
	    string expirationDate;
	    string cardNumber;

};
#endif