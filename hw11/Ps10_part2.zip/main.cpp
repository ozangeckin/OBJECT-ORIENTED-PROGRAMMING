#include<iostream>
#include "payment.h"
#include "cashpayment.h"
#include "creditcardpayment.h"
using namespace std;

int main(){
  
    CashPayment cp(125.55),cp2(45.25);
    CreditCardPayment creCp(65.12,"Alex","11/10/2020","123456789"),creCp2(121.63,"Ricardo","10/12/2022","987654321");

    cout<<"(TEST) CashPayment details of obje1:"<<endl;
    cp.paymentDetails();
    cout<<"\n(TEST) CashPayment details of obje2:"<<endl;
    cp2.paymentDetails();
    cout<<"\n(TEST) CreditCard details of obje1:"<<endl;
    creCp.paymentDetails();
    cout<<"\n(TEST) CreditCard details of obje2:"<<endl;
    creCp2.paymentDetails();

}