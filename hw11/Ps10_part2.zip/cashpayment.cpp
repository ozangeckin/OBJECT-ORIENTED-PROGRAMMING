#include<iostream>
#include"cashpayment.h"

using namespace std;

CashPayment::CashPayment():Payment(){

}
CashPayment::CashPayment(float AmountOfPayment_):Payment(AmountOfPayment_){

}
void CashPayment::paymentDetails(){
    cout<<"Amount of the cash payment: "<<getAmountOfPayment()<<endl;
}