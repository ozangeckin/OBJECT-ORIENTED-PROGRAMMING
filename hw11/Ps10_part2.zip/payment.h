#ifndef PAYMENT_H
#define PAYMENT_H
#include <iostream>
#include <string>

using namespace std;
class Payment
{

    public:
	    Payment();
	    Payment(float amountOfPayment_);
	    float getAmountOfPayment();
	    void setAmountOfPayment(float amountOfPayment_);
	    void paymentDetails();

    private:
	    float amountOfPayment;
};
#endif