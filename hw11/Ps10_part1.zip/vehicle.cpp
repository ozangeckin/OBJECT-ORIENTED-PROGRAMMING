
#include "vehicle.h"

Vehicle::Vehicle():manufacturerName(""),numberOfCylinders(0),owner(Person()){

}
Vehicle::Vehicle(const string manufacturerName_,int numberOfCylinders_,const Person owner_):manufacturerName(manufacturerName_),numberOfCylinders(numberOfCylinders_),owner(owner_){

}
Vehicle::Vehicle(const Vehicle& otObje){
    manufacturerName=otObje.manufacturerName;
    numberOfCylinders=otObje.numberOfCylinders;
    owner=otObje.owner;
}
Vehicle& Vehicle::operator=(const Vehicle& otObje){
    manufacturerName=otObje.manufacturerName;
    numberOfCylinders=otObje.numberOfCylinders;
    owner=otObje.owner;

    return *this;
}
string Vehicle::getManufacturerName()const{
    return manufacturerName;
}
int Vehicle::getNumberOfCylinders()const{
    return numberOfCylinders;
}
Person Vehicle::getOwner()const{
    return owner;
}
void Vehicle::setManufacturerName(const string manufacturerName_){
    manufacturerName=manufacturerName_;
}
void Vehicle::setNumberOfCylinders(int numberOfCylinders_){
    numberOfCylinders=numberOfCylinders_;
}
void Vehicle::setOwner(const Person& owner_){
    owner=owner_;
}
void Vehicle::print()
{
	cout << "Owner: " << owner << endl;
	cout << "Manufacturer's name: " << manufacturerName << endl;
	cout << "Number of cylinders in the engine: " << numberOfCylinders << endl;	
}