#ifndef VEHICLE_H
#define VEHICLE_H

#include"person.h"

class Vehicle{
    public:
        Vehicle();
        Vehicle(const string manufacturerName_,int numberOfCylinders_,Person owner_);
        Vehicle(const Vehicle& otObje);
        Vehicle& operator=(const Vehicle& otObje);
        string getManufacturerName()const;
        int getNumberOfCylinders()const;
        Person getOwner()const;
        void setManufacturerName(const string manufacturerName_);
        void setNumberOfCylinders(int numberOfCylinde);
        void setOwner(const Person& owner_);
        void print();
    private:
        string manufacturerName;
        int numberOfCylinders;
        Person owner;

};

#endif