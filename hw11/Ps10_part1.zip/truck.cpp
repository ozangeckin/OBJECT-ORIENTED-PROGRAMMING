#include "truck.h"

Truck::Truck() : Vehicle()
{
	// deliberately empty
}

Truck::Truck(string manufacturerName_, int numberOfCylinders_, const Person& owner_, double loadCapacity_, int towingCapacity_):Vehicle(manufacturerName_, numberOfCylinders_,owner_),loadCapacity(loadCapacity_), towingCapacity(towingCapacity_)
{
	// deliberately empty
}

Truck::Truck(const Truck& otherObject) : Vehicle(otherObject),loadCapacity(otherObject.loadCapacity), towingCapacity(otherObject.towingCapacity)
{
	// deliberately empty
}
double Truck::getLoadCapacity()
{
	return loadCapacity;
}

int Truck::getTowingCapacity()
{
	return towingCapacity;
}

void Truck::setLoadCapacity(double loadCapacity_)
{
	loadCapacity = loadCapacity_;
}

void Truck::setTowingCapacity(int towingCapacity_)
{
	towingCapacity = towingCapacity_;
}

void Truck::print()
{
	Vehicle::print();
	cout << "Load capacity in tons: " << loadCapacity << endl;
	cout << "Towing capacity in pounds: " << towingCapacity << endl;
}
