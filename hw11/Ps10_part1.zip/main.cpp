#include <iostream>
#include "truck.h"
using namespace std;

int main(){
    Person p("Ozan Geckin");
    Truck t("Ford Truck Company",3,p,30,5000);

    Truck t2(t);

    Truck t3=t2;
    cout << "Details of Truck 1" << endl;
	t.print();

	cout << "\nDetails of Truck 2" << endl;
	t2.print();

	cout << "\nDetails of Truck 3" << endl;
	t3.print();
	
	return 0;

}