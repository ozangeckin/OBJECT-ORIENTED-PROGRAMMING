#ifndef TRUCK_H
#define TRUCK_H

#include "vehicle.h"

class Truck:public Vehicle
{   
    public:
        Truck();
        Truck(string manufacturerName_,int numberOfCylinders_,const Person& owner_,double loadCapacity,int towingCapacity);
        Truck(const Truck& otObje);
        Truck& operator=(const Truck& otObje);
        double getLoadCapacity();
        int getTowingCapacity();
        void setLoadCapacity(double loadCapacity_);
        void setTowingCapacity(int towingCapacity_);
        void print();

    private:
        double loadCapacity;
        int towingCapacity;

};
#endif